import Vue from "vue"

export default new Vue({

        login(){
            this.log=1;
        }
})