<template>
    <div>
    <div class="footer">
        <div class="footer_content">
            <div>
            <span>阅文集团旗下网站：</span>
            <ul class="footer_list">
                <li><a href="javascript:;" target="_blank">起点中文网</a></li>
                <li><a href="javascript:;" target="_blank">起点女生网</a></li>
                <li><a href="javascript:;" target="_blank">创世中文网</a></li>
                <li><a href="javascript:;" target="_blank">云起书院</a></li>
                <li><a href="javascript:;" target="_blank">红袖添香</a></li>
                <li><a href="javascript:;" target="_blank">小说阅读网</a></li>
                <li><a href="javascript:;" target="_blank">言情小说吧</a></li>
                <li><a href="javascript:;" target="_blank">潇湘书院</a></li>
                <li><a href="javascript:;" target="_blank">天方听书网</a></li>
                <li><a href="javascript:;" target="_blank">懒人听书</a></li>
                <li><a href="javascript:;" target="_blank">阅文读书</a></li>
                <li><a href="javascript:;" target="_blank">QQ阅读</a></li>
                <li><a href="javascript:;" target="_blank">起点读书</a></li>
                <li><a href="javascript:;" target="_blank">作家助手</a></li>
                <li><a href="javascript:;" target="_blank">起点国际版</a></li>
            </ul>
            </div>
            <div>
                <ul>
                    <li>友情链接：</li>
                    <li>265导航</li>
                    <li>5566导航</li>
                    <li>123网址大全</li>
                    <li>九酷音乐</li>
                </ul>
            </div>
            <div>
                <ul>
                    <li>关于本站</li>
                    <li>联系我们</li>
                    <li>会员帮助</li>
                    <li>作者帮助</li>
                </ul>
            </div>
            <p>版权所有：苏州经纬网络信息科技有限公司。（101）</p>
            <p>网站备案/许可证号：苏ICP备16023960号-1  苏公网安备32059002002332号</p>
            <div>
                <img src="image/index/footer_img.png" alt="">
            </div>
        </div>
    </div>
    </div>
</template>
<script>
export default {
    
}
</script>
