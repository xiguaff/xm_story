<template>
    <div>
    <div class="list-header" :style="{'background-image':`url(../image/list/bg_${num}.jpg)`}">
        <div class="container">
            <div class="header-top">
                <div>
                    <img :src="`image/list/logo_${4}.png`" alt="">
                </div>
                <div class="intStyle">
                    <input type="text"><span><i></i><i></i></span>
                </div>
                <div class="imgStyle">
                    <a href=""><img src="image/index/header_author.jpg" alt="">我要当作家</a>
                    <a href=""><img src="image/index/header_liwu.jpeg" alt="">作家福利</a>
                </div>
            </div>
            <div class="header-bottom">
                <a href="javascript:;">古言完本小说</a>
                <a href="javascript:;">古言免费小说</a>
                <a href="javascript:;">古言包月小说</a>
                <a href="javascript:;">古言全部小说</a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="list-top">
            <div class="list-top-left">
                <div class="list-top-content">
                    <div>
                        <img src="image/list/list_1.jpg" alt="">
                    </div>
                    <div>
                        <p>极纵无双之正室指南</p>
                        <p>侧耳听风 / 著</p>
                        <p>
                            （双宠—双强—双纯）宇文玠所想的妻子是这样的：品性端良，德才兼备；秉性柔嘉，持恭淑慎。 
                            而白牡嵘完美的避过了以上每一条，对着镜子，这外形便不是居家妇女，白扯！ 穿越至此，便是新婚之夜，
                            白牡嵘暴躁的将那个娇柔易推倒的小白脸儿一顿揍。敢动手动脚？打不死这个战五渣！不过之后她就见识到了，
                            他还真不是战五渣，就是个披着完美人皮的狼！宇文玠—杀人诛心的邪魔。白牡嵘—上兵伐谋的恶鬼。 
                            二人为敌，天下大乱；二人为伍，天下更乱听风坑品有保证，欢迎亲们跳坑
                        </p>
                        <a href="javascript:;">书籍详情</a>
                    </div>
                </div>
            </div>
            <div class="list-top-right">
                <div class="right-top">
                    <div><span>编辑推荐</span><i></i></div>
                    <div>
                        <p>影月楼：我的小护卫</p>
                        <p style="color:#888;">旧时梦七月 / 著</p>
                        <p>影月楼。楼主青宛七，江湖人称：青姑娘。她从外面捡回</p>
                        <p>来个与她一样大的护卫，取名：影山。青宛七...</p>
                    </div>
                    <div>
                        <p>影月楼：我的小护卫</p>
                        <p style="color:#888;">旧时梦七月 / 著</p>
                        <p>影月楼。楼主青宛七，江湖人称：青姑娘。她从外面捡回</p>
                        <p>来个与她一样大的护卫，取名：影山。青宛七...</p> 
                    </div>
                </div>
                <div class="right-bottom">
                    <div><span>新书精选</span><i></i></div>
                    <p><span>厨女当家：山里汉子，宠不休一朝穿越成食不裹腹，家</span></p>
                    <p><span>嫡女归来之皇后太妖娆许沐晴是个狼人，比狠还多...</span></p>
                    <p><span>农家巧手妇【文案一】沈遇一觉醒来发...</span></p>
                </div>
            </div>
        </div>
        <div class="list-middle-ul">
            <div class="col-header">
                <h3>月票榜</h3>
            </div>
            <div class="i-3_content">
                <div class="list-one">
                    <img src="image/index/bangdan1.jpg" alt="">
                </div>
                <div class="icon_header">
                    <span class="num">NO.1</span>
                    <p><a href="">山河盛宴</a></p>
                    <p>作者：<span>天下归元</span></p>
                    <p><span>分类：</span>&nbsp;|&nbsp;<span>玄幻</span></p>
                </div>
            </div>
            <ul class="ul-list">
                    <li>
                        <span>11153</span>
                         <span>2</span>
                        <a href="javascript:;">夫人你马甲又掉了</a>
                    </li>
                    <li>
                        <span>9508</span>
                        <span>3</span>
                        <a href="javascript:;">名门暖婚之权爷追妻攻略</a>
                    </li>
                    <li>
                        <span>7001</span>
                        <span>4</span>
                        <a href="javascript:;">狂医废材妃</a>
                    </li>
                    <li>
                        <span>6678</span>
                        <span>5</span>
                        <a href="javascript:;">最美不过小时光</a>
                    </li>
                    <li>
                        <span>6412</span>
                        <span>6</span>
                        <a href="javascript:;">盛世娇宠之名门闺香</a>
                    </li>
                    <li>
                        <span>5425</span>
                        <span>7</span>
                        <a href="javascript:;">神医娘亲之腹黑小萌宝</a>
                    </li>
                    <li>
                        <span>4865</span>
                        <span>8</span>
                        <a href="javascript:;">战神魔妃</a>
                    </li>
                    <li>
                        <span>4235</span>
                        <span>9</span>
                        <a href="javascript:;">爷是病娇得宠着</a>
                    </li>
                    <li>
                        <span>3514</span>
                        <span>10</span>
                        <a href="javascript:;">神殿倾天之妖妃好甜</a>
                    </li>
            </ul>
        </div>
        <div class="list-middle-nav">
            <h3>频道新书</h3>
        </div>
        <div class="list-middle">
        <div class="list-middle-content">
            <div>
                <img src="image/list/list_2.jpg" alt="">
            </div>
            <div>
                <p><a href="javascript:;">我在奈何桥底算命</a></p>
                <p style="color:#888">陶四木 / 著</p>
                <p>简介:更新时间，每日早上八点。算命师版:桥底算命，童叟无欺。
                        作为一个算命的，能说会道是本事，答疑解惑是常事。木欧在奈何桥底下算命千年有余，侃天侃地侃社会，
                        上到阎罗王，下到投胎鬼，几乎都光顾过她的摊子，哪个不说她信誉好？ 直到某天摊子面前来了一个如花似玉的小仙君……
                        “奈何桥底，禁止摆摊。”“小仙君可是来砸场子的？我在奈何桥算命千年，还没有人敢砸我的场子，你信不信，我一招手，
                        就是一帮小鬼弄死你。” “……”天界铁面无私城管小仙君VS阴界最强钉子户算命师地府众鬼版:黄泉陌路，魂灵万千， 
                        红尘纷扰，遗憾执念， 喝下这孟婆汤，渡过那奈何桥，前尘往事，皆会化作忘川河水，过眼云烟一去不返。
                        不愿投胎转世的魂灵，可是生前有放不下的执念？即是如此，便去那桥底的算命师摊上算上一卦吧……
                </p>
            </div>
        </div>
        </div>
        <div class="list-middle-ul">
            <div class="col-header">
                <h3>更新榜</h3>
            </div>
            <div class="i-3_content">
                <div class="list-one">
                    <img src="image/index/bangdan2.jpg" alt="">
                </div>
                <div class="icon_header">
                    <span class="num">NO.1</span>
                    <p><a href="">山河盛宴</a></p>
                    <p>作者：<span>天下归元</span></p>
                    <p><span>分类：</span>&nbsp;|&nbsp;<span>玄幻</span></p>
                </div>
            </div>
                <ul class="ul-list">
                        <li>
                            <span>11153</span>
                             <span>2</span>
                            <a href="javascript:;">夫人你马甲又掉了</a>
                        </li>
                        <li>
                            <span>9508</span>
                            <span>3</span>
                            <a href="javascript:;">名门暖婚之权爷追妻攻略</a>
                        </li>
                        <li>
                            <span>7001</span>
                            <span>4</span>
                            <a href="javascript:;">狂医废材妃</a>
                        </li>
                        <li>
                            <span>6678</span>
                            <span>5</span>
                            <a href="javascript:;">最美不过小时光</a>
                        </li>
                        <li>
                            <span>6412</span>
                            <span>6</span>
                            <a href="javascript:;">盛世娇宠之名门闺香</a>
                        </li>
                        <li>
                            <span>5425</span>
                            <span>7</span>
                            <a href="javascript:;">神医娘亲之腹黑小萌宝</a>
                        </li>
                        <li>
                            <span>4865</span>
                            <span>8</span>
                            <a href="javascript:;">战神魔妃</a>
                        </li>
                        <li>
                            <span>4235</span>
                            <span>9</span>
                            <a href="javascript:;">爷是病娇得宠着</a>
                        </li>
                        <li>
                            <span>3514</span>
                            <span>10</span>
                            <a href="javascript:;">神殿倾天之妖妃好甜</a>
                        </li>
                </ul>
        </div>
        <div class="list-middle-nav">
                <h3>人气连载</h3>
        </div>
        <div class="list-middle">
                <div class="list-middle-content">
                    <div>
                        <img src="image/list/list_2.jpg" alt="">
                    </div>
                    <div>
                        <p><a href="javascript:;">我在奈何桥底算命</a></p>
                        <p style="color:#888">陶四木 / 著</p>
                        <p>简介:更新时间，每日早上八点。算命师版:桥底算命，童叟无欺。
                            作为一个算命的，能说会道是本事，答疑解惑是常事。木欧在奈何桥底下算命千年有余，侃天侃地侃社会，
                            上到阎罗王，下到投胎鬼，几乎都光顾过她的摊子，哪个不说她信誉好？ 直到某天摊子面前来了一个如花似玉的小仙君……
                            “奈何桥底，禁止摆摊。”“小仙君可是来砸场子的？我在奈何桥算命千年，还没有人敢砸我的场子，你信不信，我一招手，
                            就是一帮小鬼弄死你。” “……”天界铁面无私城管小仙君VS阴界最强钉子户算命师地府众鬼版:黄泉陌路，魂灵万千， 
                            红尘纷扰，遗憾执念， 喝下这孟婆汤，渡过那奈何桥，前尘往事，皆会化作忘川河水，过眼云烟一去不返。
                            不愿投胎转世的魂灵，可是生前有放不下的执念？即是如此，便去那桥底的算命师摊上算上一卦吧……
                        </p>
                    </div>
                </div>
        </div>
        <div>
            <img src="image/list/gg.jpg" alt="">
        </div>
        <div class="list-bottom">
            <div class="list-bottom-content">
                <div><img src="image/list/list_3.jpg" alt=""></div>
                <div>
                    <p><a href="">盛宠农门娇妻</a></p>
                    <p style="color:#888;">风柒染 / 著</p>
                    <p>
                        【美食】+【系统】+【异能】+【宠文一对一】+【家长里短】+【虐极品】地球末世突然降临，
                        唐妖儿不曾想，人心难测！被自己最好的蜜友所害，一腔悲愤，绝望地落入丧尸口中。一朝重生，
                        她成了大宇国天岚县黎水村连小孩子都欺负上一脚的“傻子”黎幺儿，瘦不拉几的羸弱身子，单薄的可见几两骨头。
                        彪悍肥墩的二伯娘，偏袒大房的阿奶，兴风作浪的堂姐儿……这样的亲人要来作何，分家！有一颗接受了现代精英教育的脑袋在，
                        怕啥？她要坐拥自己的美食街，让欺负过她家的人都眼红去吧！黎幺儿的蓝图里，有温和疼爱自己的家人，
                        有村子里独一份的漂亮庄园，有数不完的金山银山！但为毛，现实跟想象差距这么大？这个色胚系统能不能退货？
                        不要三天两头“鞭策”她去勾搭男人啊！黎幺儿不仅要养家人，还要养某只失忆又失明的“兔儿”。幸好有一身杀过丧尸的勇气和见识，
                        调教兔儿不成问题，抵抗极品亲戚小意思，蹭蹭蹭升级系统，斗斗情敌，一切不在话下。
                    </p>
                    <a href="javascript:;">书籍详情</a>
                </div>
            </div>
        </div>
    </div>
    </div>
</template>
<script>
export default {
    data(){
        return {

        }
    },
    props:["num"],
}
</script>
<style>
    @import url("../assets/css/list.css");
</style>
