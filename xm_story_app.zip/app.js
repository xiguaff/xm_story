const express = require("express");

const userRouter = require("./router");

const cors = require("cors");

const session = require("express-session");

const bodyParser = require("body-parser");

const app=express();

app.listen(1994);

app.use(bodyParser.urlencoded({
	extended:false
}));

app.use(cors({
    origin:["http://localhost:8080","http://127.0.0.1:8080","http://localhost:8081"],
    credentials:true,
}));

app.use(session({
    secret:"128位字符串",
    resave:true,
    saveUninitialized:true,
}));

app.use(express.static("public"));
app.use(userRouter);